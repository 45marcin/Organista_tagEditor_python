def test_import_pyprinttags():
    import pyprinttags